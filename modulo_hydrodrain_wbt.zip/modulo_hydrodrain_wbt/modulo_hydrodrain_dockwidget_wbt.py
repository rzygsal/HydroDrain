import os

from .WBT.whitebox_tools import WhiteboxTools

from qgis.core import (
    QgsProcessingUtils,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer
)

from qgis.PyQt import QtWidgets, QtGui, QtCore, uic
from qgis.PyQt.QtCore import pyqtSignal


FORM_CLASS, _ = uic.loadUiType(
    os.path.join(
        os.path.dirname(__file__),
        'modulo_hydrodrain_dockwidget_base.ui'
    )
)


class HydroDrainDockWidget(QtWidgets.QDockWidget, FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        """Constructor."""

        super().__init__(parent)

        self.setupUi(self)
        self.cmb_mdt.setCurrentIndex(-1)

        ############################################################
        # WhiteboxTools
        ############################################################

        import os
        import sys

        if sys.stdout is None:
            sys.stdout = open(os.devnull, "w")

        plugin_dir = os.path.dirname(__file__)

        self.wbt = WhiteboxTools()

        self.wbt.set_whitebox_dir(
            os.path.join(plugin_dir, "WBT")
        )

        #self.wbt.set_verbose_mode(True)

        ############################################################
        # Interfaz
        ############################################################

        self.cmb_mdt.setCurrentIndex(-1)

        self.qfw_guardar_D8.lineEdit().setPlaceholderText(
            "[Guardar en archivo temporal]"
        )

        self.qfw_guardar_red.lineEdit().setPlaceholderText(
            "[Guardar en archivo temporal]"
        )

        self.btn_generar.clicked.connect(self.generar_red)
        self.btn_ayuda.clicked.connect(self.mostrar_ayuda)

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    def _ruta_salida(self, widget, nombre):

        ruta = widget.filePath()

        if not ruta:
            ruta = QgsProcessingUtils.generateTempFilename(nombre)

        return ruta

    def generar_red(self):

        QtWidgets.QApplication.setOverrideCursor(
            QtGui.QCursor(QtCore.Qt.WaitCursor)
        )

        try:

            # 1. MDT: capa o archivo

            mdt_layer = self.cmb_mdt.currentLayer()
            mdt_path = self.qfw_abrir_mdt.filePath()

            if mdt_path:
                mdt = mdt_path

            elif mdt_layer:
                mdt = mdt_layer.source()

            else:
                QtWidgets.QMessageBox.warning(
                    self,
                    "HydroDrain",
                    "Debes seleccionar un MDT o elegir un archivo."
                )
                return

            # 2. Umbral

            umbral = self.qsb_umbral.value()

            # 3. Rutas de salida

            ruta_d8 = self._ruta_salida(
                self.qfw_guardar_D8,
                "d8.tif"
            )

            ruta_red = self._ruta_salida(
                self.qfw_guardar_red,
                "red.shp"
            )

            # 4. Temporales

            ruta_fill = QgsProcessingUtils.generateTempFilename("fill.tif")
            ruta_acc = QgsProcessingUtils.generateTempFilename("acc.tif")
            ruta_str = QgsProcessingUtils.generateTempFilename("streams.tif")

            # Whitebox necesita un directorio de trabajo

            self.wbt.set_working_dir(
                os.path.dirname(ruta_fill)
            )

            ##############################################################
            # 5. FillDepressions
            ##############################################################

            print("Paso 1/5: FillDepressions")

            ret = self.wbt.fill_depressions(
                dem=mdt,
                output=ruta_fill,
                fix_flats=True,
                flat_increment=None,
                max_depth=None
            )

            if ret:
                raise RuntimeError("Error ejecutando FillDepressions")

            ##############################################################
            # 6. D8FlowAccumulation
            ##############################################################

            print("Paso 2/5: D8FlowAccumulation")

            ret = self.wbt.d8_flow_accumulation(
                i=ruta_fill,
                output=ruta_acc,
                out_type="cells",
                log=False,
                clip=False,
                pntr=False,
                esri_pntr=False
            )

            if ret:
                raise RuntimeError("Error ejecutando D8FlowAccumulation")

            ##############################################################
            # 7. D8Pointer
            ##############################################################

            print("Paso 3/5: D8Pointer")

            ret = self.wbt.d8_pointer(
                dem=ruta_fill,
                output=ruta_d8,
                esri_pntr=False
            )

            if ret:
                raise RuntimeError("Error ejecutando D8Pointer")

            ##############################################################
            # 8. ExtractStreams
            ##############################################################

            print("Paso 4/5: ExtractStreams")

            ret = self.wbt.extract_streams(
                flow_accum=ruta_acc,
                output=ruta_str,
                threshold=umbral,
                zero_background=False
            )

            if ret:
                raise RuntimeError("Error ejecutando ExtractStreams")

            ##############################################################
            # 9. RasterStreamsToVector
            ##############################################################

            print("Paso 5/5: RasterStreamsToVector")

            ret = self.wbt.raster_streams_to_vector(
                streams=ruta_str,
                d8_pntr=ruta_d8,
                output=ruta_red,
                esri_pntr=False
            )

            if ret:
                raise RuntimeError("Error ejecutando RasterStreamsToVector")

            ##############################################################
            # 10. Cargar resultados
            ##############################################################

            nombre_d8 = os.path.basename(ruta_d8)
            nombre_red = os.path.basename(ruta_red)

            capa_d8 = QgsRasterLayer(ruta_d8, nombre_d8)
            capa_red = QgsVectorLayer(ruta_red, nombre_red, "ogr")

            if capa_d8.isValid():
                QgsProject.instance().addMapLayer(capa_d8)
            else:
                print("Capa D8 inválida:", ruta_d8)

            if capa_red.isValid():
                QgsProject.instance().addMapLayer(capa_red)
            else:
                print("Capa red inválida:", ruta_red)

            print("Proceso completado")

            QtWidgets.QMessageBox.information(
                self,
                "HydroDrain",
                "Proceso finalizado correctamente."
            )

        except Exception as e:

            QtWidgets.QMessageBox.critical(
                self,
                "HydroDrain",
                str(e)
            )

        finally:

            QtWidgets.QApplication.restoreOverrideCursor()

    def mostrar_ayuda(self):
        QtWidgets.QMessageBox.information(
            self,
            "Ayuda de HydroDrain",
            "1) Selecciona un MDT desde capa o archivo.\n"
            "2) Define el umbral de acumulación.\n"
            "   El umbral ('Channelization threshold') es el número mínimo de celdas que\n"
            "   deben drenar hacia un punto para formar un cauce. Cada celda tiene un área \n"
            "   real, por lo que el umbral equivale a un área mínima de contribución.\n"
            "   Ejemplo: resolución 5 m → 25 m² por celda; umbral 200 → 5.000 m².\n"
            "   Umbral alto = red más simple; umbral bajo = red más densa.\n"
            "3) Opcional: elige rutas de salida para el ráster D8 y la red vectorial.\n"
            "4) Pulsa 'Ejecutar' para iniciar el proceso.\n\n"
            "El plugin utiliza WhiteboxTools integrado en el propio plugin."
        )